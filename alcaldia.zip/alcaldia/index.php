<?php
header("Location: vista/inicio.html");
exit();
?>